export class BasketSizeReport {
  public totalSizeMB: number = 0;
  public fileCount: number = 0;
  public constructor() {
    //
  }
}
