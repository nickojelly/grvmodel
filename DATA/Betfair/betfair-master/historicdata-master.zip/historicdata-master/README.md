# Read Me

## Getting Started
Add a .env file to the root folder and add a line like this:  
`BFTOKEN=XXX`

## Setup & Run tests
```
npm install
npm run test
```