# Help

Please try the following channels for any support:

- [Betfair Developer Support](https://docs.developer.betfair.com/display/1smk3cen4v3lu3yomq5qye0ni/Developer+Support)
- [Slack Group](https://betfairlightweight.herokuapp.com) for any help in using the library
- [API Status](https://status.developer.betfair.com/) if things don't seem to be working
